Hello,

Thank for downloading Winter Poppins.

NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 

-------
Paypal account for donation : https://www.paypal.me/almnd
-------

Link to purchase full version and commercial license: 
https://fontbundles.net/avotype/404406-winter-poppins-handwritten-font


Please visit our store for more great fonts : 
https://fontbundles.net/avotype/402314-coastal-musk-elegant-signature-font

And follow my social media for update!
 *instagram : @avotype
 *twitter   : @avotype_

If there is a problem, question, or anything about my fonts, please sent an email to

info.avotype@gmail.com


Thanks,


Avotype Studio